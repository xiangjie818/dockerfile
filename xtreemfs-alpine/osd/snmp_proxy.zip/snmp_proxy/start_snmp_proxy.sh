#!/bin/bash

python3 snmp_proxy.py > logs/snmp_proxy.log 2>&1 &
